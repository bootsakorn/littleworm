<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Athiti&amp;subset=thai" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="index_style.css">
    <link rel="stylesheet" type="text/css" href="regis_select_style.css">
    <title>Register</title>

  </head>
  <body>
    <?php
      include "center.php";
      $page = new Page();
      $page->header();
      echo '
	    <div class="collapse navbar-collapse" id="myNavbar">
	      <ul class="nav navbar-nav">
	        <li class="active"><a href="#">Home</a></li>
	        <li><a href="#">Technology</a></li>
	        <li><a href="#">Education</a></li>
	        <li><a href="#">Financial</a></li>
	        <li><a href="#">Health</a></li>
	        <li><a href="#">Social</a></li>
	        <li><a href="#">Hobbies</a></li>
	      </ul>
	      <ul class="nav navbar-nav navbar-right">
	        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign in</a></li>
	        <li><a href="#"><span class="glyphicon glyphicon-plus-sign"></span> Register</a></li>
	      </ul>
	    </div>
	  </div>
	</nav>';
    ?>
    <div class="regisBody">
      <h1>Register</h1>
      <p>โปรดเลือกประเภทที่ต้องการ</p>
      <table class="btn_table">
        <tr>
          <td>
            <form action="user_regis.php">
                <input type="submit" class="btn" name="btn_user" value="USER">
            </form>
          </td>
          <td>
            <form action="organize_regis.php">
                <input type="submit" class="btn" name="btn_organizer" value="ORGANIZER">
            </form>
          </td>
        </tr>
      </table>
    </div>
    <?php
      $page->footer();
    ?>

  </body>
</html>
