<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Athiti&amp;subset=thai" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="index_style.css">
    <title>ยืนยันการจ่ายเงิน</title>
    <style>
      .check_money_body{
        padding-left: 25%;
        padding-right: 25%;
      }
      .btn_table{
        margin: auto;
      }
      .btn {
        margin: 20px;
        font-size: 30px;
        background-color: #ffffff;
      }
    </style>

  </head>
  <body>
    <?php
      include "center.php";
      $page = new Page();
      $page->header();
      echo '
	    <div class="collapse navbar-collapse" id="myNavbar">
	      <ul class="nav navbar-nav">
	        <li class="active"><a href="#">Home</a></li>
	        <li><a href="#">Technology</a></li>
	        <li><a href="#">Education</a></li>
	        <li><a href="#">Financial</a></li>
	        <li><a href="#">Health</a></li>
	        <li><a href="#">Social</a></li>
	        <li><a href="#">Hobbies</a></li>
	      </ul>
	      <ul class="nav navbar-nav navbar-right">
	        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign in</a></li>
	        <li><a href="#"><span class="glyphicon glyphicon-plus-sign"></span> Register</a></li>
	      </ul>
	    </div>
	  </div>
	</nav>';
    ?>
    <div class="check_money_body">
      <h1>ตรวจสอบการจ่ายเงิน</h1>
      <img src="" alt="">
      <table class="btn_table">
        <tr>
          <td>
            <button class="btn" type="button" name="btn_pass">ผ่าน</button>
          </td>
          <td>
            <button class="btn" type="button" name="btn_notpass">ไม่ผ่าน</button>
          </td>
        </tr>
      </table>

    </div>
    <?php
      $page->footer();
    ?>

  </body>
</html>
